// cypress/e2e/users.create.cy.js

// Quiet the noisy Livewire frontend exceptions
const IGNORE_RE =
  /Livewire|Component already (registered|initialized)|Snapshot missing|reading 'focus'|reading 'uri'/;
Cypress.on('uncaught:exception', (err) => (IGNORE_RE.test(err.message) ? false : true));

const BASE        = Cypress.env('base') || 'http://172.164.240.105';
const LOGIN_URL   = `${BASE}/login`;
const USERS_URL   = `${BASE}/users`;
const ADMIN_EMAIL = 'admin@gmail.com';
const ADMIN_PASS  = 'admin123';

// ---------- helpers ----------
const loginUI = () => {
  cy.visit(LOGIN_URL);

  cy.get(
    'input[placeholder*="Type your email" i],input[type="email"],#email,input[name*="email" i]',
    { timeout: 15000 }
  )
    .filter(':visible')
    .first()
    .should('be.visible')
    .clear()
    .type(ADMIN_EMAIL);

  cy.get(
    'input[placeholder*="Type your password" i],input[type="password"],#password,input[name*="password" i]',
    { timeout: 15000 }
  )
    .filter(':visible')
    .first()
    .should('be.visible')
    .clear()
    .type(ADMIN_PASS, { log: false });

  cy.contains('button,[type="submit"]', /log\s*in|sign\s*in|submit|continue/i, { timeout: 15000 })
    .should('be.visible')
    .click({ force: true });

  cy.location('pathname', { timeout: 20000 }).should('include', '/dashboard');
};

const gotoUsersAndEnsureList = () => {
  cy.visit(USERS_URL);
  cy.get('table,[role="table"],.table', { timeout: 20000 }).should('exist');
  cy.get('table tbody tr,[role="row"]', { timeout: 20000 }).its('length').should('be.gte', 1);
};

// robust click on “+ Add User” (text OR aria/ title; falls back to DOM scan)
const clickAddUser = () => {
  // try the normal way first
  cy.contains('button,a,[role="button"]', /\+?\s*Add User/i, { timeout: 6000 })
    .filter(':visible')
    .first()
    .then(($btn) => {
      if ($btn.length) {
        cy.wrap($btn).scrollIntoView().click({ force: true });
        return;
      }

      // fallback: scan the DOM for any control that looks like Add User
      cy.document().then((doc) => {
        const btn = [...doc.querySelectorAll('button,a,[role="button"]')].find((el) => {
          const txt = (el.textContent || '').trim();
          const ar  = (el.getAttribute('aria-label') || '').trim();
          const ti  = (el.getAttribute('title') || '').trim();
          return /add user/i.test(txt) || /add user/i.test(ar) || /add user/i.test(ti);
        });
        expect(btn, 'found an Add User control').to.exist;
        cy.wrap(btn).scrollIntoView().click({ force: true });
      });
    });
};

// wait until the Add form is actually rendered (no strict header dependency)
const waitAddFormReady = () => {
  cy.get('body', { timeout: 35000 }).should(($b) => {
    const text = $b.text();
    const hasHeader = /Add User/i.test(text);
    const hasFirst  = $b.find('input[placeholder*="enter first name" i]:visible').length > 0;
    const hasSave   = [...$b.find('button:visible')].some((n) => /save/i.test(n.textContent || ''));
    expect(hasHeader || hasFirst || hasSave, 'Add User UI visible').to.be.true;
  });
};

// visible placeholder typer
const typePH = (pattern, val) =>
  cy
    .get('input,textarea', { timeout: 15000 })
    .filter(':visible')
    .filter((_, el) => new RegExp(pattern, 'i').test(el.getAttribute('placeholder') || ''))
    .first()
    .should('be.visible')
    .clear()
    .type(val);

// choose first company from custom dropdown
const pickCompanyFirst = () => {
  cy.contains(/Select Company/i, { timeout: 15000 })
    .filter(':visible')
    .first()
    .click({ force: true });

  cy.get('[role="option"], ul[role="listbox"] li, .dropdown-menu li', { timeout: 15000 })
    .filter(':visible')
    .filter((_, el) => !/select company/i.test((el.textContent || '').trim()))
    .first()
    .click({ force: true });
};

// ---------- test ----------
describe('Users – Add User', () => {
  it('clicks "+ Add User", fills the form, saves, and sees user in the list', () => {
    loginUI();
    gotoUsersAndEnsureList();

    clickAddUser();
    // brief settle for Livewire bursts
    cy.wait(400);
    waitAddFormReady();

    const ts = Date.now();
    const user = {
      first: 'Cypress',
      last:  `Tester${ts}`,
      uname: `cyuser${ts}`,
      email: `cy${ts}@example.com`,
      pass:  'Password!',
    };

    typePH('^Enter first name$', user.first);
    typePH('^Enter last name$',  user.last);
    typePH('^Enter user name$',  user.uname);
    typePH('^Enter email$',      user.email);

    // user type default is "Erp" – leave as-is
    pickCompanyFirst();

    typePH('^Enter password$',          user.pass);
    typePH('Enter password to confirm', user.pass);

    cy.contains('button,[role="button"]', /^Save$/i, { timeout: 15000 })
      .filter(':visible')
      .first()
      .scrollIntoView()
      .click({ force: true });

    // verify in list
    cy.wait(800); // let Livewire refresh
    cy.visit(USERS_URL);
    cy.contains(user.email, { timeout: 20000 }).scrollIntoView().should('be.visible');
  });
});
