describe('COA – list', () => {
  before(() => cy.loginAndBindTenant()); // your existing login helper
  beforeEach(() => cy.goToCOA());

  it('shows list and essential columns', () => {
    cy.get('table:visible', { timeout: 30000 }).first().within(() => {
      ['Code', 'Account Name', 'Account Group', 'Account Type', 'Sub Type'].forEach(h => {
        cy.contains('th,td', new RegExp(`^\\s*${h}\\s*$`, 'i')).should('exist');
      });
    });
  });

  it('searches by account code', () => {
    cy.get('input[placeholder*="Search" i], input[placeholder*="Account" i]')
      .first().clear().type('101001');
    cy.contains('td,div', /^\s*101001\s*$/).should('exist');
  });
});
