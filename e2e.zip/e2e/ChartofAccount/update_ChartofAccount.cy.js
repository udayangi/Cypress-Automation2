describe('COA – update', () => {
  before(() => cy.loginAndBindTenant());
  beforeEach(() => cy.openCOAList());

  it('opens an existing account and updates fields', () => {
    cy.fixture('coa_update.json').then((r) => {
      // open row (adapt selector for your action column)
      cy.contains('td,div', new RegExp(`^\\s*${r.AccountCode}\\s*$`))
        .closest('tr')
        .within(() => {
          cy.contains('a,button', /Edit|Update/i).click({ force: true });
        });

      cy.contains(/Edit Account|Update Account|Chart of Account/i, { timeout: 15000 }).should('be.visible');

      if (r.NewAccountName) cy.coaType(/Account Name/i, r.NewAccountName);
      if (r.NewGroup)       cy.coaSelect(/Account Group/i, r.NewGroup);
      if (r.ToggleActive !== undefined) cy.coaToggle(/Active|Status/i, r.ToggleActive);

      cy.coaSubmit();
      cy.contains(/Updated|Saved|Success/i, { timeout: 8000 }).should('be.visible');

      // verify on list
      cy.openCOAList();
      cy.contains('td,div', new RegExp(`^\\s*${r.AccountCode}\\s*$`)).parents('tr').within(() => {
        if (r.NewAccountName) cy.contains(new RegExp(`^\\s*${r.NewAccountName}\\s*$`, 'i')).should('exist');
        if (r.NewGroup)       cy.contains(new RegExp(`^\\s*${r.NewGroup}\\s*$`, 'i')).should('exist');
      });
    });
  });
});
