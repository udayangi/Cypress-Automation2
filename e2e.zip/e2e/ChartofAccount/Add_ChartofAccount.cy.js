
describe('COA – add', () => {
  before(() => cy.loginAndBindTenant());
  beforeEach(() => cy.openCOAList());

  it('creates a new account (from fixture)', () => {
    cy.fixture('coa_create.json').then((r) => {
      cy.openCOACreate();

      cy.coaType(/Account Name/i, r.AccountName);
      cy.coaType(/Account Code/i, r.AccountCode);
      if (r.Type)    cy.coaSelect(/Account Type/i, r.Type);
      if (r.SubType) cy.coaSelect(/Account Sub Type/i, r.SubType);
      if (r.Group)   cy.coaSelect(/Account Group/i, r.Group);
      if (r.Reconciliation === true) cy.coaToggle(/Allow Reconciliation/i, true);

      cy.coaSubmit();
      cy.contains(/Saved|Created|Success/i, { timeout: 8000 }).should('be.visible');

      // verify on list
      cy.openCOAList();
      cy.contains('td,div', new RegExp(`^\\s*${r.AccountCode}\\s*$`)).should('exist');
      cy.contains('td,div', new RegExp(`^\\s*${r.AccountName}\\s*$`, 'i')).should('exist');
    });
  });

  it('rejects duplicates', () => {
    cy.fixture('coa_create.json').then((r) => {
      cy.openCOACreate();
      cy.coaType(/Account Name/i, r.AccountName);
      cy.coaType(/Account Code/i, r.AccountCode);
      cy.coaSubmit();
      cy.contains(/already exists|duplicate/i, { timeout: 8000 }).should('be.visible');
    });
  });
});

