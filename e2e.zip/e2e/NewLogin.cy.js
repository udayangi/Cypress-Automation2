// Be tolerant of Livewire front-end noise so tests don't false-fail
const IGNORE_RE =
  /Livewire|Component already (registered|initialized)|Snapshot missing|reading 'focus'|reading 'uri'/;
Cypress.on('uncaught:exception', (err) => (IGNORE_RE.test(err.message) ? false : true));

const BASE = Cypress.env('base') || 'http://172.164.240.105';
const LOGIN_URL = `${BASE}/login`;

const ADMIN_EMAIL = Cypress.env('adminEmail') || 'admin@gmail.com';
const ADMIN_PASS  = Cypress.env('adminPass')  || 'admin123';
const BAD_EMAIL   = 'wrong@gmail.com';
const BAD_PASS    = 'wrongpass';

// Helpers that DO NOT use `[attr*="... i"]`
const getForm = () => cy.get('form', { timeout: 15000 }).should('exist');

const findEmailInput = () =>
  getForm().find('input').filter((_, el) => {
    const type = (el.getAttribute('type') || '').toLowerCase();
    const id = (el.id || '').toLowerCase();
    const name = (el.getAttribute('name') || '').toLowerCase();
    const ph = (el.getAttribute('placeholder') || '').toLowerCase();
    return type === 'email' || id.includes('email') || name.includes('email') || ph.includes('email');
  }).first();

const findPasswordInput = () =>
  getForm().find('input').filter((_, el) => {
    const type = (el.getAttribute('type') || '').toLowerCase();
    const id = (el.id || '').toLowerCase();
    const name = (el.getAttribute('name') || '').toLowerCase();
    const ph = (el.getAttribute('placeholder') || '').toLowerCase();
    return type === 'password' || id.includes('password') || name.includes('password') || ph.includes('password');
  }).first();

const findRememberMe = () =>
  getForm().find('input[type="checkbox"]').filter(':visible').first();

const clickSubmit = () =>
  getForm().within(() => {
    cy.contains('button,[type="submit"]', /log\s*in|sign\s*in|submit|continue/i, { timeout: 15000 })
      .should('exist')
      .click({ force: true });
  });

const expectOnDashboard = () => {
  cy.location('pathname', { timeout: 20000 }).should('include', '/dashboard');
  cy.get('body').should('not.contain', 'These credentials do not match');
};

describe('GemNex ERP – New Login (fixed selectors)', () => {
  beforeEach(() => {
    cy.visit(LOGIN_URL);
  });

  it('logs in successfully with valid Admin credentials', () => {
    findEmailInput().should('be.visible').clear().type(ADMIN_EMAIL);
    findPasswordInput().should('be.visible').clear().type(ADMIN_PASS, { log: false });
    clickSubmit();
    expectOnDashboard();
  });

  it('rejects invalid email with valid password', () => {
    findEmailInput().type(BAD_EMAIL);
    findPasswordInput().type(ADMIN_PASS, { log: false });
    clickSubmit();

    cy.location('pathname').should('include', '/login');
    cy.contains(/do not match|invalid|failed|try again/i, { timeout: 10000 }).should('exist');
  });

  it('rejects valid email with wrong password', () => {
    findEmailInput().type(ADMIN_EMAIL);
    findPasswordInput().type(BAD_PASS, { log: false });
    clickSubmit();

    cy.location('pathname').should('include', '/login');
    cy.contains(/do not match|invalid|failed|try again/i, { timeout: 10000 }).should('exist');
  });

  it('blocks submit when both fields are empty (HTML5 validity)', () => {
    clickSubmit();

    findEmailInput().then(($el) => {
      const msg = ($el[0].validationMessage || '').toLowerCase();
      expect(msg).to.match(/please|valid|fill/);
    });
  });

  it('blocks submit when only email is filled', () => {
    findEmailInput().type(ADMIN_EMAIL);
    clickSubmit();

    findPasswordInput().then(($el) => {
      const msg = ($el[0].validationMessage || '').toLowerCase();
      expect(msg).to.match(/please|valid|fill/);
    });
  });

  it('blocks submit when only password is filled', () => {
    findPasswordInput().type(ADMIN_PASS, { log: false });
    clickSubmit();

    findEmailInput().then(($el) => {
      const msg = ($el[0].validationMessage || '').toLowerCase();
      expect(msg).to.match(/please|valid|fill/);
    });
  });

  it('logs in with "Remember me" checked (if present)', () => {
    findEmailInput().type(ADMIN_EMAIL);
    findPasswordInput().type(ADMIN_PASS, { log: false });
    findRememberMe().then(($cb) => { if ($cb.length) cy.wrap($cb).check({ force: true }); });
    clickSubmit();
    expectOnDashboard();
  });

  it('remembered email on reload (strict only if implemented)', () => {
    findEmailInput().type(ADMIN_EMAIL);
    findPasswordInput().type(ADMIN_PASS, { log: false });
    findRememberMe().then(($cb) => { if ($cb.length) cy.wrap($cb).check({ force: true }); });
    clickSubmit();
    expectOnDashboard();

    cy.clearCookies();
    cy.clearLocalStorage();
    cy.visit(LOGIN_URL);

    findEmailInput().should('have.value', ADMIN_EMAIL);
    findPasswordInput().should('have.value', '');
    findRememberMe().then(($cb) => { if ($cb.length) cy.wrap($cb).should('be.checked'); });
  });
});
