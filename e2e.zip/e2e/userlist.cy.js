// cypress/e2e/accounting_journal_bankEntry.cy.js

// --- Mute noisy Livewire exceptions so runs don’t abort ---
const IGNORE_RE =
  /Livewire|Component already (registered|initialized)|Snapshot missing|Could not find Livewire component|reading 'focus'|reading 'uri'|Cannot read properties of undefined|option is not defined/;
Cypress.on('uncaught:exception', (err) => (IGNORE_RE.test(err.message) ? false : true));

// --- Config / env ---
const BASE      = Cypress.env('base') || 'http://172.164.240.105';
const LOGIN_URL = `${BASE}/login`;

// --- Network helpers to tame Livewire churn ---
const interceptLivewire = () => {
  cy.intercept('POST', '**/livewire/update').as('lwUpdate');
  cy.intercept('POST', '**/livewire/message/**').as('lwMsg');
};

/**
 * Waits briefly for recent Livewire traffic, but never fails the chain if none arrives.
 * NOTE: Cypress chainables don't support .catch(); use .then(null, ...) to swallow.
 */
const waitLivewireIdle = () => {
  cy.wait(['@lwUpdate', '@lwMsg'], { timeout: 20000 })
    .then(() => cy.wait(80))
    .then(null, () => {}); // swallow any wait errors (e.g., if no recent LW requests)
};

// --- Generic click by text (button/anchor/role=button) ---
const clickAny = (rx) =>
  cy.contains('button,a,[role="button"]', rx, { timeout: 20000 })
    .scrollIntoView()
    .should('be.visible')
    .click({ force: true });

// --- Login that tolerates Livewire + optional tenant picker ---
const loginTenant = () => {
  interceptLivewire();
  cy.visit(LOGIN_URL);

  cy.get(
    [
      'input[placeholder*="Type your email" i]',
      'input[type="email"]',
      'input#email',
      'input[name*="email" i]',
    ].join(',')
  )
    .filter(':visible')
    .first()
    .should('be.visible')
    .clear()
    .type(Cypress.env('email') || 'asjhq@asj.com', { delay: 20 });

  cy.get(
    [
      'input[placeholder*="Type your password" i]',
      'input[type="password"]',
      'input#password',
      'input[name*="password" i]',
    ].join(',')
  )
    .filter(':visible')
    .first()
    .should('be.visible')
    .clear()
    .type(Cypress.env('password') || 'password', { log: false, delay: 20 });

  clickAny(/log\s*in|sign\s*in|submit|continue/i);
  waitLivewireIdle();

  // If tenant selector appears, pick ASJ (or first visible option)
  cy.location('pathname', { timeout: 25000 }).then((p) => {
    if (p.includes('/select-tenant')) {
      cy.contains(/ASJ|Al Sulaiman|Select/i, { timeout: 15000 }).click({ force: true });
      waitLivewireIdle();
    }
  });

  cy.url({ timeout: 30000 }).should('match', /dashboard/);
};

// --- Preserve current ?tenant=... when going to /journal-entries ---
const openJournalEntries = () => {
  cy.location().then(({ search }) => {
    const qs = (search || '').trim();
    cy.visit(`${BASE}/journal-entries${qs || '?'}`);
  });
  interceptLivewire();
  waitLivewireIdle();

  // Open the JE form (top green button)
  cy.contains(/Add Journal Item/i, { timeout: 20000 })
    .scrollIntoView()
    .should('be.visible')
    .click({ force: true });
  waitLivewireIdle();

  // Transaction Type is static – just assert JE / Journal Entry shows
  cy.contains(/Transaction Type/i)
    .parent()
    .should('contain.text', 'JE')
    .and('contain.text', 'Journal Entry');
};

// --- Small utilities for the row form ---
const typeIntoAuto = (chainableInput, text, pickMatcher = /./) => {
  chainableInput.clear().type(text, { delay: 20 });
  cy.get('ul[role="listbox"] li:visible, [role="option"]:visible, .autocomplete li:visible', {
    timeout: 12000,
  })
    .filter((_, el) => new RegExp(pickMatcher, 'i').test(el.textContent || ''))
    .first()
    .click({ force: true });
  waitLivewireIdle();
};

const addLine = (accountText, amount) => {
  // Account autocomplete
  const accountInput = cy
    .get('input[placeholder*="Search"][placeholder*="Account" i]', { timeout: 10000 })
    .filter(':visible')
    .first()
    .should('be.visible');

  typeIntoAuto(accountInput, accountText, accountText);

  // Optional: department/location if required – choose first available
  cy.contains(/^Departments\b/i)
    .parent()
    .find('input:visible')
    .then(($inp) => {
      if ($inp.length) {
        cy.wrap($inp.first()).click({ force: true }).type('All', { delay: 20 });
        cy.get('ul[role="listbox"] li:visible, [role="option"]:visible')
          .first()
          .click({ force: true });
        waitLivewireIdle();
      }
    });

  cy.contains(/^Location Tag/i)
    .parent()
    .find('select:visible')
    .then(($sel) => {
      if ($sel.length) {
        const $first = $sel.find('option').filter((_, o) => (o.value || '').trim()).first();
        if ($first.length) cy.wrap($sel).select($first.val(), { force: true });
        waitLivewireIdle();
      }
    });

  // Amount
  cy.contains(/^Amount$/i).parent().find('input:visible').first().clear().type(String(amount), { delay: 15 });

  // Add to grid
  clickAny(/Add to Journal Items/i);
  waitLivewireIdle();
};

const readNumber = (txt) => Number(String(txt).replace(/[^\d.-]/g, '') || 0);
const assertTotalsBalance = (expected) => {
  const grab = (label) =>
    cy
      .contains(new RegExp(`^${label}$`, 'i'))
      .parent()
      .invoke('text')
      .then(readNumber);

  cy.wrap(null).then(async () => {
    const debit = await grab('Debit');
    const credit = await grab('Credit');
    expect(debit, 'debit total').to.eq(expected);
    expect(credit, 'credit total').to.eq(expected);
  });
};

// --- TEST ---
describe('Journal Entries – Bank Entry (tenant)', () => {
  it('adds 2 lines (200 debit to Barwa Bank, 200 credit to 24K Carat) and balances totals', () => {
    loginTenant();
    openJournalEntries();

    // If the side menu overlays the form (like in your screenshot), press ESC to close it
    cy.get('body').type('{esc}', { force: true });

    // 1) Barwa Bank — 200 (deposit/inflow)
    addLine(Cypress.env('bankAccount') || 'Barwa Bank', 200);

    // 2) 24K Carat — 200 (offset)
    addLine(Cypress.env('offsetAccount') || '24K Carat', 200);

    // Totals must match
    assertTotalsBalance(200);
  });
});
