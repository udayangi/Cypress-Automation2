// cypress/e2e/users.create.cy.js

// Ignore noisy Livewire frontend exceptions so tests don't false-fail
const IGNORE_RE =
  /Livewire|Component already (registered|initialized)|Snapshot missing|reading 'focus'|reading 'uri'/;
Cypress.on('uncaught:exception', (err) => (IGNORE_RE.test(err.message) ? false : true));

const BASE        = Cypress.env('base') || 'http://172.164.240.105';
const LOGIN_URL   = `${BASE}/login`;
const USERS_URL   = `${BASE}/users`;
const ADMIN_EMAIL = 'admin@gmail.com';
const ADMIN_PASS  = 'admin123`';

// ---- small helpers ----
const loginUI = () => {
  cy.visit(LOGIN_URL);

  // robust email / password finders
  cy.get('input[placeholder*="Type your email" i], input[type="email"], input#email, input[name*="email" i]')
    .filter(':visible')
    .first()
    .should('be.visible')
    .clear()
    .type(ADMIN_EMAIL);

  cy.get('input[placeholder*="Type your password" i], input[type="password"], input#password, input[name*="password" i]')
    .filter(':visible')
    .first()
    .should('be.visible')
    .clear()
    .type(ADMIN_PASS, { log: false });

  cy.contains('button,[type="submit"]', /log\s*in|sign\s*in|submit|continue/i, { timeout: 15000 })
    .should('be.visible')
    .click({ force: true });

  cy.location('pathname', { timeout: 20000 }).should('include', '/dashboard');
};

const waitUsersListReady = () => {
  cy.visit(USERS_URL);
  cy.get('table,[role="table"],.table', { timeout: 20000 }).should('exist');
  cy.get('table tbody tr,[role="row"]', { timeout: 20000 }).its('length').should('be.gte', 1);
};

const openAddUserForm = () => {
  // intercept Livewire to allow a short settle wait
  cy.intercept('POST', '/livewire/update').as('lw');

  // click the visible + Add User button on the toolbar
  cy.contains('button,a,[role="button"]', /\+?\s*Add User/i, { timeout: 15000 })
    .filter(':visible')
    .first()
    .scrollIntoView()
    .click({ force: true });

  // give Livewire a moment if it fires
  cy.wait(500);
  cy.wait('@lw', { timeout: 8000 }).its('response.statusCode').should('be.oneOf', [200, 204]);

  // guard: "Add User" header + first-name placeholder must be visible
  cy.contains(/^Add User$/i, { timeout: 35000 }).should('be.visible');
  cy.get('input:visible')
    .filter((_, el) => /(^|\s)enter first name|^first name$/i.test(el.getAttribute('placeholder') || ''))
    .should('have.length.at.least', 1);
};

const typePH = (re, value) =>
  cy.get('input,textarea', { timeout: 15000 })
    .filter(':visible')
    .filter((_, el) => new RegExp(re, 'i').test(el.getAttribute('placeholder') || ''))
    .first()
    .should('be.visible')
    .clear()
    .type(value);

const pickCompanyFirst = () => {
  // open the Company dropdown
  cy.contains(/Select Company/i, { timeout: 15000 })
    .filter(':visible')
    .first()
    .click({ force: true });

  // pick the first visible option that isn't the placeholder
  cy.get('[role="option"], ul[role="listbox"] li, .dropdown-menu li', { timeout: 15000 })
    .filter(':visible')
    .filter((_, el) => !/select company/i.test((el.textContent || '').trim()))
    .first()
    .click({ force: true });
};

// ---- the test ----
describe('Users – Add User', () => {
  it('clicks "+ Add User", fills the form, saves, and sees user in the list', () => {
    loginUI();
    waitUsersListReady();
    openAddUserForm();

    const ts = Date.now();
    const user = {
      first: 'Cypress',
      last:  `Tester${ts}`,
      uname: `cyuser${ts}`,
      email: `cy${ts}@example.com`,
      pass:  'Passw0rd!',
    };

    // Fill form by placeholders exactly as in the UI
    typePH('^Enter first name$', user.first);
    typePH('^Enter last name$',  user.last);
    typePH('^Enter user name$',  user.uname);
    typePH('^Enter email$',      user.email);

    // User Type shows "Erp" by default – leave as-is
    pickCompanyFirst();

    typePH('^Enter password$',              user.pass);
    typePH('Enter password to confirm',     user.pass);

    // Save
    cy.contains('button,[role="button"]', /^Save$/i, { timeout: 20000 })
      .filter(':visible')
      .first()
      .click({ force: true });

    // Allow Livewire to process, then go back to list and assert
    cy.wait(1000);
    cy.visit(USERS_URL);
    cy.contains(user.email, { timeout: 20000 })
      .scrollIntoView()
      .should('be.visible');
  });
});
