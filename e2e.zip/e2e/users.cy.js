// cypress/e2e/users.cy.js

// Ignore noisy Livewire exceptions
const IGNORE_RE =
  /Livewire|Component already (registered|initialized)|Snapshot missing|reading 'focus'|reading 'uri'/;
Cypress.on('uncaught:exception', (err) => (IGNORE_RE.test(err.message) ? false : true));

const BASE = Cypress.env('base') || 'http://172.164.240.105';
const LOGIN_URL = `${BASE}/login`;
const USERS_URL = `${BASE}/users`;
const ADMIN_EMAIL = 'admin@gmail.com';
const ADMIN_PASS  = 'admin123';

// ---- helpers ----
const getForm = () => cy.get('form', { timeout: 15000 }).should('exist');

const findEmailInput = () =>
  getForm().find('input').filter((_, el) => {
    const t = (el.getAttribute('type') || '').toLowerCase();
    const id = (el.id || '').toLowerCase();
    const name = (el.getAttribute('name') || '').toLowerCase();
    const ph = (el.getAttribute('placeholder') || '').toLowerCase();
    return t === 'email' || id.includes('email') || name.includes('email') || ph.includes('email');
  }).first();

const findPasswordInput = () =>
  getForm().find('input').filter((_, el) => {
    const t = (el.getAttribute('type') || '').toLowerCase();
    const id = (el.id || '').toLowerCase();
    const name = (el.getAttribute('name') || '').toLowerCase();
    const ph = (el.getAttribute('placeholder') || '').toLowerCase();
    return t === 'password' || id.includes('password') || name.includes('password') || ph.includes('password');
  }).first();

const submitLogin = () =>
  getForm().within(() => {
    cy.contains('button,[type="submit"]', /log\s*in|sign\s*in|submit|continue/i, { timeout: 15000 })
      .click({ force: true });
  });

const loginAsAdmin = () => {
  cy.visit(LOGIN_URL);
  findEmailInput().should('be.visible').clear().type(ADMIN_EMAIL);
  findPasswordInput().should('be.visible').clear().type(ADMIN_PASS, { log: false });
  submitLogin();
  cy.location('pathname', { timeout: 20000 }).should('include', '/dashboard');
};

const ensureSession = () => {
  cy.session(['admin', ADMIN_EMAIL], loginAsAdmin, { cacheAcrossSpecs: true });
};

// ---- tests ----
describe('GemNex ERP – Users list & profile', () => {
  beforeEach(() => {
    ensureSession();
  });

  it('loads the Users page and shows at least one row', () => {
    cy.visit(USERS_URL);

    // Header text can vary; accept any of these or just assert table exists
    cy.get('table,[role="table"],.table', { timeout: 20000 }).should('exist');

    // At least one data row
    cy.get('table tbody tr,[role="row"]', { timeout: 20000 })
      .its('length')
      .should('be.gte', 1);
  });

  it('navigates to a user profile when a user is clicked', () => {
    cy.visit(USERS_URL);

    // Click a direct link if present, else click the first row
    cy.get('table tbody tr', { timeout: 20000 }).should('have.length.gte', 1).first().then($row => {
      const $link = $row.find('a[href*="/users/"]');
      if ($link.length) {
        cy.wrap($link[0]).click({ force: true });
      } else {
        // some tables use wire:click on the row
        cy.wrap($row).click({ force: true });
      }
    });

    // Either it navigates to /users/:id OR opens a drawer/modal with profile
    cy.location('pathname', { timeout: 20000 }).then((path) => {
      if (/\/users\/[^/]+$/.test(path)) return; // navigated

      // fallback: profile opened inline (drawer/modal)
      cy.get('body').then(($b) => {
        const hasDrawer =
          $b.find('[role="dialog"],[data-drawer],.drawer,.offcanvas,.modal').length > 0 ||
          /user profile|profile|details|edit user/i.test($b.text());
        expect(hasDrawer, 'profile visible (drawer/modal or text)').to.be.true;
      });
    });
  });
});
